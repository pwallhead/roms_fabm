/*
** Include file "swancpp.h"
**
** svn $Id: swancpp.h 995 2020-01-10 04:01:28Z arango $
********************************************************** Hernan G. Arango ***
** Copyright (c) 2002-2020 The ROMS/TOMS Group                               **
**   Licensed under a MIT/X style license                                    **
**   See License_ROMS.txt                                                    **
*******************************************************************************
**                                                                           **
** Include ROMS CPP definitions.
*/

#include "cppdefs.h"
